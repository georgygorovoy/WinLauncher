use xodus::licensing::splicense::{DeviceKey, SPLicense};
use xodus::models::live::ExchangeUserTokenOutcome;
use xodus::models::secrets::Token;
use xodus::models::soap;
use xodus::tokens::TokenManager;

pub async fn get_license(
    client: &reqwest::Client,
    tokens: &TokenManager,
    content_id: String,
    market: String,
) -> std::result::Result<(DeviceKey, SPLicense), String> {
    let dev_token = tokens.get_device_sts_token().map_err(|_| "Device sign-in is unavailable".to_string())?;
    let Token::Legacy(dev_token) = dev_token else {
        return Err("Invalid STS token".to_string());
    };
    let user = tokens.get_user().map_err(|_| "Microsoft account profile is unavailable".to_string())?;
    let user_token = tokens.get_user_sts_token().map_err(|_| "Microsoft sign-in is unavailable".to_string())?;
    let Token::Legacy(legacy) = user_token else {
        return Err("Unspported user token".to_string());
    };

    let ms_device_token = xodus::api::live::exchange_device_token(
        client,
        dev_token.clone(),
        "{d6d5a677-0872-4ab0-9442-bb792fce85c5}".to_string(),
        "www.microsoft.com".to_owned(),
        Some(soap::PolicyReference::mbi_ssl()),
    )
    .await
    .map_err(|_| "Microsoft device-ticket exchange failed".to_string())?;

    let user_token = xodus::api::live::exchange_user_token(
        client,
        legacy,
        user.username,
        dev_token,
        None,
        Some("Silent".to_string()),
        "{d6d5a677-0872-4ab0-9442-bb792fce85c5}".to_string(),
        &[(
            "www.microsoft.com".to_owned(),
            Some(soap::PolicyReference::mbi_ssl()),
        )],
    )
    .await
    .map_err(|_| "Microsoft user-ticket exchange failed".to_string())?;

    let ms_device_token = compact_token(ms_device_token)?;

    let user_token = match user_token {
        ExchangeUserTokenOutcome::Fault(_) => {
            return Err("Failed to get exchange MS token".to_string());
        }
        ExchangeUserTokenOutcome::Issued(
            soap::BodyContent::RequestSecurityTokenResponseCollection(collection),
        ) => collection.security_tokens.into_iter().next()
            .ok_or_else(|| "Microsoft returned no user ticket".to_string())?,
        ExchangeUserTokenOutcome::Issued(soap::BodyContent::RequestSecurityTokenResponse(
            token,
        )) => *token,
        _ => return Err("Microsoft returned an unsupported user-ticket response".to_string()),
    };
    let user_token = xodus::models::secrets::licensing_ticket(compact_token(user_token)?);

    let (_content, game_license) = xodus::licensing::content::get_license_content(
        client,
        ms_device_token,
        user_token,
        user.puid,
        content_id,
        market,
    )
    .await
    .map_err(|err| err.to_string())?;

    let game_splicense = SPLicense::parse_base64(&game_license.splicense_block)
        .map_err(|_| "Microsoft returned an invalid game license".to_string())?;

    let dev_license = tokens.get_device_license()
        .map_err(|_| "Saved device license is unavailable".to_string())?;
    let device_license = SPLicense::parse_base64(&dev_license.splicense)
        .map_err(|_| "Saved device license is invalid".to_string())?;
    let key = device_license
        .encrypted_device_key
        .ok_or_else(|| "Saved device license has no key".to_string())?
        .derive_device_key();
    Ok((key, game_splicense))
}

fn compact_token(response: soap::RequestSecurityTokenResponse) -> Result<String, String> {
    let value = response.requested_security_token.binary_security_token
        .ok_or_else(|| "Microsoft ticket payload is missing".to_string())?
        .value;
    match response.token_type.as_str() {
        "urn:passport:compact" => Ok(value),
        "urn:passport:delegationcompact" => Ok(format!("d={value}")),
        _ => Err("Microsoft returned an unsupported ticket type".to_string()),
    }
}
