//! Real Store license tokens for the account selected when the service starts.
//! No Xbox-user substitution, entitlement synthesis, caching, or payload logs.
use std::sync::Arc;
use std::time::Duration;

use base64::prelude::*;

use super::content::{LicenseTokenError, get_license_token};
use crate::models::live::ExchangeUserTokenOutcome;
use crate::models::secrets::{LegacyToken, Token, User};
use crate::models::soap;
use crate::models::xgameruntime::xstore::{
    LicenseTokenRequest, LicenseTokenResponse, StoreContextResponse,
};
use crate::tokens::TokenManager;

pub const INVALID_ARGUMENT: u32 = 0x80070057;
pub const INVALID_HANDLE: u32 = 0x80070006;
pub const NOT_LOGGED_ON: u32 = 0x800704dd;
pub const ACCESS_DENIED: u32 = 0x80070005;
pub const TIMEOUT: u32 = 0x800705b4;
pub const FAILURE: u32 = 0x80004005;
pub const MAX_REQUEST_BYTES: usize = 8192;
const STORE_HOSTING_APP: &str = "{d6d5a677-0872-4ab0-9442-bb792fce85c5}";
const STORE_RELYING_PARTY: &str = "www.microsoft.com";

struct AccountSnapshot {
    user: User,
    user_sts: LegacyToken,
    device_sts: LegacyToken,
}

pub struct StoreLicenseSession {
    binding: String,
    account: Option<AccountSnapshot>,
    client: reqwest::Client,
    request_lock: tokio::sync::Mutex<()>,
}

fn unexpired(expires: &str) -> bool {
    chrono::DateTime::parse_from_rfc3339(expires)
        .is_ok_and(|expiry| expiry.timestamp() > chrono::Utc::now().timestamp())
}

fn capture_account(tokens: &TokenManager) -> Option<AccountSnapshot> {
    let user = tokens.get_user().ok()?;
    let Token::Legacy(user_sts) = tokens.get_user_sts_token().ok()? else {
        return None;
    };
    let Token::Legacy(device_sts) = tokens.get_device_sts_token().ok()? else {
        return None;
    };
    // Detect a selection change during the initial multi-key read. No subsequent
    // request reads account selection or persists refreshed credentials.
    let checked_user = tokens.get_user().ok()?;
    let Token::Legacy(checked_sts) = tokens.get_user_sts_token().ok()? else {
        return None;
    };
    if user.puid.is_empty()
        || user.username.is_empty()
        || user.puid != checked_user.puid
        || user.username != checked_user.username
        || user_sts.token != checked_sts.token
        || !unexpired(&user_sts.lifetime.expires)
        || !unexpired(&device_sts.lifetime.expires)
    {
        return None;
    }
    let secret = BASE64_STANDARD
        .decode(device_sts.binary_secret.as_ref()?)
        .ok()?;
    if secret.len() != 4096 {
        return None;
    }
    Some(AccountSnapshot {
        user,
        user_sts,
        device_sts,
    })
}

impl StoreLicenseSession {
    pub async fn new(tokens: Arc<TokenManager>) -> Result<Self, reqwest::Error> {
        let mut bytes: [u8; 16] = rand::random();
        bytes[6] = (bytes[6] & 0x0f) | 0x40;
        bytes[8] = (bytes[8] & 0x3f) | 0x80;
        // Keychain APIs can wait synchronously for an OS permission dialog.
        // Do not block an async worker or bypass that dialog. A timed-out
        // snapshot stays unavailable for this session even if its worker later
        // completes; a newly selected account requires a new service session.
        let account = match tokio::time::timeout(
            Duration::from_secs(25),
            tokio::task::spawn_blocking(move || capture_account(&tokens)),
        )
        .await
        {
            Ok(Ok(account)) => account,
            _ => None,
        };
        Ok(Self {
            binding: uuid::Uuid::from_bytes(bytes).to_string(),
            account,
            client: reqwest::Client::builder()
                .https_only(true).referer(false)
                .connect_timeout(Duration::from_secs(8))
                .timeout(Duration::from_secs(20))
                .redirect(reqwest::redirect::Policy::none())
                .connection_verbose(false)
                .build()?,
            request_lock: tokio::sync::Mutex::new(()),
        })
    }

    pub fn create_context(&self) -> StoreContextResponse {
        let available = self.account.as_ref().is_some_and(|account| {
            unexpired(&account.user_sts.lifetime.expires)
                && unexpired(&account.device_sts.lifetime.expires)
        });
        StoreContextResponse {
            hresult: if available { 0 } else { NOT_LOGGED_ON },
            account_binding: if available {
                self.binding.clone()
            } else {
                String::new()
            },
        }
    }

    pub async fn query_license(&self, request: LicenseTokenRequest) -> LicenseTokenResponse {
        let result = if !valid_request(&request) {
            Err(INVALID_ARGUMENT)
        } else if request.account_binding != self.binding {
            Err(INVALID_HANDLE)
        } else {
            match tokio::time::timeout(Duration::from_secs(25), async {
                let _guard = self.request_lock.lock().await;
                self.acquire(&request).await
            })
            .await
            {
                Ok(result) => result,
                Err(_) => Err(TIMEOUT),
            }
        };
        match result {
            Ok(token) => LicenseTokenResponse { hresult: 0, token },
            Err(hresult) => LicenseTokenResponse {
                hresult,
                token: String::new(),
            },
        }
    }

    async fn acquire(&self, request: &LicenseTokenRequest) -> Result<String, u32> {
        let account = self.account.as_ref().ok_or(NOT_LOGGED_ON)?;
        if !unexpired(&account.user_sts.lifetime.expires)
            || !unexpired(&account.device_sts.lifetime.expires)
        {
            return Err(NOT_LOGGED_ON);
        }
        let device = crate::api::live::exchange_device_token(
            &self.client,
            account.device_sts.clone(),
            STORE_HOSTING_APP.into(),
            STORE_RELYING_PARTY.into(),
            Some(soap::PolicyReference::mbi_ssl()),
        )
        .await
        .map_err(|_| FAILURE)?;
        let device_token = compact_store_token(device)?;
        let user = crate::api::live::exchange_user_token(
            &self.client,
            account.user_sts.clone(),
            account.user.username.clone(),
            account.device_sts.clone(),
            None,
            Some("Silent".into()),
            STORE_HOSTING_APP.into(),
            &[(
                STORE_RELYING_PARTY.into(),
                Some(soap::PolicyReference::mbi_ssl()),
            )],
        )
        .await
        .map_err(|_| FAILURE)?;
        let user = match user {
            ExchangeUserTokenOutcome::Issued(soap::BodyContent::RequestSecurityTokenResponse(
                value,
            )) => *value,
            ExchangeUserTokenOutcome::Issued(
                soap::BodyContent::RequestSecurityTokenResponseCollection(collection),
            ) => {
                let mut matching = collection.security_tokens.into_iter().filter(|token| {
                    token.applies_to.endpoint_reference.address == STORE_RELYING_PARTY
                });
                let token = matching.next().ok_or(FAILURE)?;
                if matching.next().is_some() {
                    return Err(FAILURE);
                }
                token
            }
            _ => return Err(ACCESS_DENIED),
        };
        let user_token = compact_store_token(user)?;
        get_license_token(
            &self.client,
            device_token,
            user_token,
            account.user.puid.clone(),
            request.parent_product_id.clone(),
            request.product_ids.clone(),
            request.custom_developer_string.clone(),
        )
        .await
        .map_err(|error| match error {
            LicenseTokenError::ServerStatus(401 | 403) => ACCESS_DENIED,
            LicenseTokenError::ServerStatus(400) => INVALID_ARGUMENT,
            LicenseTokenError::Request(error) if error.is_timeout() => TIMEOUT,
            _ => FAILURE,
        })
    }
}

fn compact_store_token(response: soap::RequestSecurityTokenResponse) -> Result<String, u32> {
    if response.applies_to.endpoint_reference.address != STORE_RELYING_PARTY
        || !unexpired(&response.lifetime.expires)
    {
        return Err(FAILURE);
    }
    let token = response
        .requested_security_token
        .binary_security_token
        .ok_or(FAILURE)?
        .value;
    if token.is_empty() || token.len() > 65_535 {
        return Err(FAILURE);
    }
    match response.token_type.as_str() {
        "urn:passport:compact" => Ok(token),
        "urn:passport:delegationcompact" => Ok(format!("d={token}")),
        _ => Err(FAILURE),
    }
}

pub fn valid_request(request: &LicenseTokenRequest) -> bool {
    let product =
        |value: &str| value.len() == 12 && value.bytes().all(|c| c.is_ascii_alphanumeric());
    request.account_binding.len() == 36
        && uuid::Uuid::parse_str(&request.account_binding).is_ok()
        && product(&request.parent_product_id)
        && !request.product_ids.is_empty()
        && request.product_ids.len() <= 32
        && request.product_ids.iter().all(|value| product(value))
        && !request.custom_developer_string.is_empty()
        && request.custom_developer_string.len() <= 4096
        && !request
            .custom_developer_string
            .chars()
            .any(|c| c == '\0' || (c < ' ' && c != '\t' && c != '\n' && c != '\r'))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn request() -> LicenseTokenRequest {
        LicenseTokenRequest {
            account_binding: "12345678-1234-4234-8234-123456789abc".into(),
            parent_product_id: "9N6JF50HZFW9".into(),
            product_ids: vec!["9N6JF50HZFW9".into()],
            custom_developer_string: "test-challenge".into(),
        }
    }

    #[test]
    fn request_bounds_fail_closed() {
        assert!(valid_request(&request()));
        let mut value = request();
        value.product_ids.clear();
        assert!(!valid_request(&value));
        value = request();
        value.product_ids = vec!["9N6JF50HZFW9".into(); 33];
        assert!(!valid_request(&value));
        value = request();
        value.parent_product_id = "9N6JF50HZFW/".into();
        assert!(!valid_request(&value));
        value = request();
        value.custom_developer_string = "a".repeat(4096);
        assert!(valid_request(&value));
        value.custom_developer_string.push('a');
        assert!(!valid_request(&value));
        value = request();
        value.custom_developer_string.push('\0');
        assert!(!valid_request(&value));
    }

    #[test]
    fn wire_preserves_order_and_exact_challenge() {
        let xml = "<LicenseTokenRequest><AccountBinding>12345678-1234-4234-8234-123456789abc</AccountBinding><ParentProductId>9N6JF50HZFW9</ParentProductId><ProductId>9N6JF50HZFW9</ProductId><ProductId>AAAAAAAAAAAA</ProductId><CustomDeveloperString>a&amp;b&lt;c&gt;&#13;&#10;</CustomDeveloperString></LicenseTokenRequest>";
        let value: LicenseTokenRequest = quick_xml::de::from_str(xml).expect("valid test XML");
        assert_eq!(value.product_ids, ["9N6JF50HZFW9", "AAAAAAAAAAAA"]);
        assert_eq!(value.custom_developer_string, "a&b<c>\r\n");
        assert!(valid_request(&value));
    }
}
