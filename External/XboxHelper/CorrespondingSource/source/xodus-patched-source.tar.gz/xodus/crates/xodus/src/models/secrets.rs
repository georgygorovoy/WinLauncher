use serde::{Deserialize, Serialize};

use crate::models::soap::{self, Timestamp};

#[derive(Debug, Serialize, Deserialize)]
pub struct Device {
    pub puid: String,
    pub hwid: String,
    pub device_id: String,
    pub splicense: String,
    pub username: String,
    pub password: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct LegacyToken {
    pub key_name: Option<String>,
    pub token: String,
    pub binary_secret: Option<String>,
    #[serde(default)]
    pub tpm_key: Option<String>,
    pub lifetime: Timestamp,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
#[serde(untagged)]
pub enum Token {
    Legacy(LegacyToken),
    Compact(String),
}

impl From<soap::RequestSecurityTokenResponse> for Token {
    fn from(value: soap::RequestSecurityTokenResponse) -> Self {
        match value.token_type.as_str() {
            "urn:passport:legacy" => {
                let encrypted_data = value.requested_security_token.encrypted_data.unwrap();
                let key_name = encrypted_data.key_info.key_name.clone();
                let token = quick_xml::se::to_string(&encrypted_data).unwrap();
                let binary_secret = value
                    .requested_proof_token
                    .as_ref()
                    .map(|t| t.binary_secret.clone());
                let tpm_key = value
                    .requested_proof_token
                    .and_then(|t| t.encrypted_key.map(|k| k.cipher_data.cipher_value));
                Self::Legacy(LegacyToken {
                    key_name,
                    token,
                    binary_secret,
                    tpm_key,
                    lifetime: value.lifetime,
                })
            }
            "urn:passport:compact" => Self::Compact(
                value
                    .requested_security_token
                    .binary_security_token
                    .unwrap()
                    .value,
            ),
            "urn:passport:delegationcompact" => Self::Compact(format!(
                "d={}",
                value
                    .requested_security_token
                    .binary_security_token
                    .unwrap()
                    .value
            )),
            _ => unreachable!(),
        }
    }
}

/// Format a user ticket only when it is sent to content licensing. Compact JWE
/// tickets use their bare representation, unlike opaque delegation tickets.
/// Keep the stored Xbox token unchanged so the same sign-in remains reusable.
pub fn licensing_ticket(ticket: String) -> String {
    let bare = ticket
        .strip_prefix("d=")
        .or_else(|| ticket.strip_prefix("t="))
        .unwrap_or(&ticket);
    if is_compact_jwe(bare) {
        bare.to_string()
    } else if let Some(value) = ticket.strip_prefix("d=") {
        format!("t={value}")
    } else {
        ticket
    }
}

// This recognizes wire encoding, not authenticity or entitlement. Microsoft
// still validates the complete encrypted ticket. Its payload is never decoded.
fn is_compact_jwe(value: &str) -> bool {
    use base64::{Engine, engine::general_purpose::URL_SAFE_NO_PAD};
    let mut segments = value.split('.');
    let Some(header) = segments.next() else { return false; };
    if header.is_empty() || header.len() > 8192 { return false; }
    let Some(key) = segments.next() else { return false; };
    let Some(iv) = segments.next() else { return false; };
    let Some(ciphertext) = segments.next() else { return false; };
    let Some(tag) = segments.next() else { return false; };
    if segments.next().is_some() || iv.is_empty() || ciphertext.is_empty() || tag.is_empty() {
        return false;
    }
    if ![header, key, iv, ciphertext, tag].iter().all(|part| {
        part.len() % 4 != 1
            && part.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_')
    }) {
        return false;
    }
    let Ok(header) = URL_SAFE_NO_PAD.decode(header) else { return false; };
    let Ok(header) = serde_json::from_slice::<serde_json::Value>(&header) else { return false; };
    ["alg", "enc"].iter().all(|key| {
        header.get(key).and_then(|value| value.as_str()).is_some_and(|value| !value.is_empty())
    })
}

#[cfg(test)]
mod licensing_ticket_tests {
    use super::licensing_ticket;

    #[test]
    fn formats_jwe_and_opaque_delegation_tickets_for_content_licensing() {
        let jwe = "eyJhbGciOiJkaXIiLCJlbmMiOiJBMTI4Q0JDLUhTMjU2In0..aXY.Y2lwaGVy.dGFn";
        assert_eq!(licensing_ticket(format!("d={jwe}")), jwe);
        assert_eq!(licensing_ticket(format!("t={jwe}")), jwe);
        assert_eq!(licensing_ticket("d=opaque".into()), "t=opaque");
        assert_eq!(licensing_ticket("t=opaque&p=proof".into()), "t=opaque&p=proof");
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct TokenStore {
    #[serde(flatten)]
    pub tokens: std::collections::HashMap<String, Token>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct User {
    pub puid: String,
    pub username: String,
}
