use crate::models::xbox::{
    UserAuthProperties, UserAuthRequest, XstsPropertyBag, XstsRequest, XstsResponse,
};

pub async fn authenticate_xbox_user(
    client: &reqwest::Client,
    rps_ticket: String,
) -> reqwest::Result<XstsResponse> {
    async fn request(client: &reqwest::Client, ticket: String) -> reqwest::Result<reqwest::Response> {
        let body = UserAuthRequest {
            relying_party: "http://auth.xboxlive.com".to_string(),
            token_type: "JWT".to_string(),
            properties: UserAuthProperties {
                auth_method: "RPS".to_string(),
                site_name: "user.auth.xboxlive.com".to_string(),
                rps_ticket: ticket,
            },
        };
        client
            .post("https://user.auth.xboxlive.com/user/authenticate")
            .header("Content-Type", "application/json")
            .header("x-xbl-contract-version", "1")
            .json(&body)
            .send()
            .await
    }

    let retry_ticket = crate::models::secrets::xbox_user_auth_retry_ticket(&rps_ticket);
    let response = request(client, rps_ticket).await?;
    if response.status() == reqwest::StatusCode::BAD_REQUEST {
        eprintln!("BEDROCK_XBOX_AUTH_DIAGNOSTIC:stage=user_auth;status=400;retry_eligible={}", retry_ticket.is_some());
        if let Some(ticket) = retry_ticket {
            let response = request(client, ticket).await?;
            eprintln!("BEDROCK_XBOX_AUTH_DIAGNOSTIC:stage=user_auth_retry;status={}", response.status().as_u16());
            return response.error_for_status()?.json().await;
        }
    }
    response.error_for_status()?.json().await
}

pub async fn request_xsts_token(
    client: &reqwest::Client,
    token: String,
    relying_party: &str,
) -> reqwest::Result<XstsResponse> {
    let body = XstsRequest {
        relying_party: Some(relying_party.to_string()),
        token_type: Some("JWT".to_string()),
        properties: XstsPropertyBag {
            user_tokens: Some(vec![token]),
            sandbox_id: Some("RETAIL".to_string()),
            delegation_token: None,
            service_token: None,
        },
    };

    let resp = client
        .post("https://xsts.auth.xboxlive.com/xsts/authorize")
        .header("Content-Type", "application/json")
        .header("x-xbl-contract-version", "1")
        .json(&body)
        .send()
        .await?
        .error_for_status()?;

    resp.json().await
}

pub fn get_xsts_auth_header(xsts: XstsResponse) -> String {
    let uhs = xsts.user_hash().expect("XSTS response missing xui claim");
    format!("XBL3.0 x={uhs};{}", xsts.token)
}
