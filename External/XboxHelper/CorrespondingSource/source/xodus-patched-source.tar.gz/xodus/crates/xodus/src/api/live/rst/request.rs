use std::collections::HashMap;

use base64::prelude::*;

use crate::api::live::utils;
use crate::models::soap;

pub struct RSTRequest<'a> {
    pub signed_xml: String,
    pub signature: Option<super::RSTSignature<'a>>,
}

impl<'a> RSTRequest<'a> {
    /// Makes a POST request with `reqwest::Client` and decrypts the envelope if applicable
    pub async fn request(
        self,
        client: &reqwest::Client,
    ) -> Result<soap::Envelope, super::RSTError> {
        tracing::trace!("Making RST2.srf request");
        let mut response = client
        .post("https://login.live.com/RST2.srf")
        .header("User-Agent", "MSAWindows/55 (OS 10.0.26100.0.0 ge_release; IDK 10.0.26100.5074 ge_release; Cfg 16.000.29325.00; Test 0)")
        .header("Content-Type", "application/soap+xml")
        .header("Host", "login.live.com")
        .body(self.signed_xml)
        .send()
        .await?;
        let http_success = response.status().is_success();

        // Bound authentication material before XML parsing/decryption. Preserve
        // SOAP fault handling for callers that use HTTP errors for auth flows.
        const RESPONSE_LIMIT: usize = 1024 * 1024;
        if response.content_length().is_some_and(|size| size > RESPONSE_LIMIT as u64) {
            return Err(super::RSTError::UnexpectedResponse);
        }
        let mut bytes = Vec::new();
        while let Some(chunk) = response.chunk().await? {
            if chunk.len() > RESPONSE_LIMIT - bytes.len() {
                return Err(super::RSTError::UnexpectedResponse);
            }
            bytes.extend_from_slice(&chunk);
        }
        let response_text = String::from_utf8(bytes).map_err(|_| super::RSTError::UnexpectedResponse)?;
        let envelope: soap::Envelope = quick_xml::de::from_str(&response_text)?;

        let envelope = verify_and_decrypt_envelope(self.signature, response_text, envelope)?;
        // Keep SOAP faults available to interactive auth callers, but never
        // accept an issued-token-shaped body from a failed HTTP exchange.
        if !http_success && !matches!(&envelope.body.body, soap::BodyContent::Fault(_)) {
            return Err(super::RSTError::UnexpectedResponse);
        }
        Ok(envelope)
    }
}

fn verify_and_decrypt_envelope<'a>(
    signature: Option<super::RSTSignature<'a>>,
    xml_text: String,
    mut envelope: soap::Envelope,
) -> Result<soap::Envelope, super::RSTError> {
    let Some(signature) = signature else {
        tracing::debug!("No signature, returning raw envelope");
        return Ok(envelope);
    };
    tracing::trace!("Decrypting soap::Envelope");
    let nonces: HashMap<String, String> = envelope
        .header
        .security
        .derived_key_tokens
        .iter()
        .map(|token| (token.id.clone(), token.nonce.clone()))
        .collect();

    if let Some(security_signature) = &envelope.header.security.signature
        && let Some(key_info) = &security_signature.key_info
    {
        let id = &key_info.security_token_reference.reference.uri;
        let id = id.strip_prefix('#').filter(|id| !id.is_empty()).ok_or(super::RSTError::MissingNonce)?;
        let nonce = nonces.get(id).ok_or(super::RSTError::MissingNonce)?;
        let nonce = BASE64_STANDARD.decode(nonce)?;
        let key = signature.signing_key(&nonce)?;
        let mut kmgr = bergshamra::KeysManager::new();
        kmgr.add_key(bergshamra::Key::new(key, bergshamra::KeyUsage::Verify));
        let ctx = bergshamra::DsigContext::new(kmgr).with_strict_verification(false);
        let result = bergshamra::verify(&ctx, &xml_text)?;
        match result {
            bergshamra::VerifyResult::Invalid { reason } => {
                return Err(super::RSTError::InvalidResponseSignature(reason));
            }
            bergshamra::VerifyResult::Valid { .. } => tracing::debug!("Verification successful"),
        }
    }

    if envelope.header.pp.is_none()
        && let Some(enc_pp) = envelope.header.encrypted_pp.take()
    {
        tracing::trace!("Decrypting soap::PP");
        let pp = utils::decrypt_soap_encrypted_data(
            Box::new(enc_pp.encrypted_data),
            &signature,
            &nonces,
        )?;
        envelope.header.pp = pp;
    }

    if let soap::BodyContent::EncryptedData(enc_data) = envelope.body.body {
        tracing::trace!("Decrypting soap::Body");
        envelope.body.body = utils::decrypt_soap_encrypted_data(enc_data, &signature, &nonces)?;
    }

    Ok(envelope)
}
