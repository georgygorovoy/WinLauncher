use serde::{Deserialize, Serialize};

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct StoreContextRequest {}

#[derive(Serialize)]
#[serde(rename_all = "PascalCase")]
pub struct StoreContextResponse {
    #[serde(rename = "HResult")]
    pub hresult: u32,
    pub account_binding: String,
}

#[derive(Deserialize)]
#[serde(rename_all = "PascalCase", deny_unknown_fields)]
pub struct LicenseTokenRequest {
    pub account_binding: String,
    pub parent_product_id: String,
    #[serde(rename = "ProductId", default)]
    pub product_ids: Vec<String>,
    pub custom_developer_string: String,
}

#[derive(Serialize)]
#[serde(rename_all = "PascalCase")]
pub struct LicenseTokenResponse {
    #[serde(rename = "HResult")]
    pub hresult: u32,
    pub token: String,
}
