use std::fs::Permissions;
use std::os::unix::fs::PermissionsExt;
use std::sync::Arc;
use tokio::net::UnixListener;
use tokio_util::sync::CancellationToken;
use xodus::tokens::TokenManager;
mod connection;
mod simple_context;
mod utils;
const XML_MAGIC: u32 = 0x58445358;
const PROTO_MAGIC: u32 = 0x58445350;
pub async fn run(tokens: Arc<TokenManager>) {
    let client = reqwest::Client::builder().https_only(true)
        .redirect(reqwest::redirect::Policy::none()).referer(false)
        .build().expect("Unable to initialize secure account transport");
    xodus::tokens::device::ensure_device_credentials(&client, &tokens).await;
    let xodus::models::secrets::Token::Legacy(device_token) =
        tokens.get_device_sts_token().unwrap()
    else {
        panic!("Device token isnt legacy")
    };

    let runtime_dir = utils::get_runtime_dir();
    // Fixed Store selection for this process; later CLI account changes cannot
    // redirect a context that is already bound to this session.
    let store_session = Arc::new(xodus::licensing::store::StoreLicenseSession::new(tokens.clone()).await
        .expect("Unable to initialize Store licensing client"));
    let cancellation = CancellationToken::new();
    let socket_path = format!("{runtime_dir}/xodus.sock");
    let trigger = cancellation.clone();
    tokio::spawn(async move {
        tokio::signal::ctrl_c()
            .await
            .expect("Failure to handle ctrl_c");
        trigger.cancel();
    });
    {
        let listener = UnixListener::bind(&socket_path).expect("Unable to bind to socket");
        let mode = 0o600;
        let perms = Permissions::from_mode(mode);
        tokio::fs::set_permissions(&socket_path, perms).await
            .expect("Unable to restrict socket permissions");
        loop {
            let accept = tokio::select! {
                r = listener.accept() => r,
                _ = cancellation.cancelled() => break,
            }
            .expect("Failed to accept");

            let token = cancellation.clone();
            let device_token = device_token.clone();
            let tokens = tokens.clone();
            let store_session = store_session.clone();
            tokio::spawn(async move {
                connection::router::route(accept.0, token, device_token, tokens, store_session).await
            });
        }
    }

    _ = tokio::fs::remove_file(socket_path).await;
}
