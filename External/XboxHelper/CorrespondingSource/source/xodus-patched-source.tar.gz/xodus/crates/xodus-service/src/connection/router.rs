use std::sync::Arc;

use tokio::io::AsyncReadExt;
use tokio_util::sync::CancellationToken;
use xodus::models::secrets::LegacyToken;
use xodus::tokens::TokenManager;

use crate::simple_context::SimpleContext;

pub async fn route(
    mut socket: tokio::net::UnixStream,
    token: CancellationToken,
    device_token: LegacyToken,
    tokens: Arc<TokenManager>,
    store_session: Arc<xodus::licensing::store::StoreLicenseSession>,
) {
    let cred = socket.peer_cred().ok().and_then(|cred| cred.pid());
    tracing::debug!("Connection from pid {cred:?}");

    let mut context = SimpleContext::new(device_token, tokens, store_session);
    loop {
        let mut read_magic = [0; 4];
        if token.is_cancelled() {
            return;
        }
        let read = socket.read_exact(&mut read_magic).await;
        if let Err(err) = read {
            tracing::error!("Failed to read magic: {err:?}");
            return;
        }

        let magic = u32::from_le_bytes(read_magic);
        let res = match magic {
            crate::XML_MAGIC => super::xml::handle(&mut socket, &mut context).await,
            crate::PROTO_MAGIC => super::proto::handle(&mut socket, &mut context).await,
            _ => {
                tracing::error!("Unknown magic");
                return;
            }
        };

        if let Err(err) = res {
            tracing::error!("There was an error handling the message: {err}");
        }
    }
}
