use xodus::licensing::store::{self, StoreLicenseSession};
use xodus::models::xgameruntime::xstore::{
    LicenseTokenRequest, LicenseTokenResponse, StoreContextRequest, StoreContextResponse,
};
use xodus::proto::xodus::XodusMessageType;

// POSIX uid_t is uint32_t on both supported service targets (macOS/Linux).
unsafe extern "C" {
    fn geteuid() -> u32;
}
pub fn effective_uid() -> u32 {
    unsafe { geteuid() }
}

fn root_is(bytes: &[u8], expected: &[u8]) -> bool {
    let mut reader = quick_xml::Reader::from_reader(bytes);
    loop {
        match reader.read_event() {
            Ok(quick_xml::events::Event::Start(start) | quick_xml::events::Event::Empty(start)) => {
                return start.name().as_ref().as_bytes() == expected && start.attributes().next().is_none();
            }
            Ok(quick_xml::events::Event::Decl(_)) => continue,
            Ok(quick_xml::events::Event::Text(text))
                if text.as_ref().bytes().all(|byte| byte.is_ascii_whitespace()) =>
            {
                continue;
            }
            // No DTD/custom entities, comments, or alternate root names.
            _ => return false,
        }
    }
}

pub async fn reply(
    session: &StoreLicenseSession,
    kind: XodusMessageType,
    bytes: &[u8],
    permitted: bool,
) -> Vec<u8> {
    let validation_error = if !permitted {
        Some(store::ACCESS_DENIED)
    } else if bytes.len() > store::MAX_REQUEST_BYTES {
        Some(store::INVALID_ARGUMENT)
    } else {
        None
    };
    // Parse errors are never formatted: they can contain caller-controlled data.
    if kind == XodusMessageType::StoreContextRequest {
        let response = if let Some(hresult) = validation_error {
            StoreContextResponse {
                hresult,
                account_binding: String::new(),
            }
        } else if !root_is(bytes, b"StoreContextRequest")
            || quick_xml::de::from_reader::<_, StoreContextRequest>(bytes).is_err()
        {
            StoreContextResponse {
                hresult: store::INVALID_ARGUMENT,
                account_binding: String::new(),
            }
        } else {
            session.create_context()
        };
        return quick_xml::se::to_string(&response).ok().filter(|s| s.len() <= 1024)
            .unwrap_or_else(|| "<StoreContextResponse><HResult>2147500037</HResult><AccountBinding/></StoreContextResponse>".into()).into_bytes();
    }
    let response = if let Some(hresult) = validation_error {
        LicenseTokenResponse {
            hresult,
            token: String::new(),
        }
    } else if !root_is(bytes, b"LicenseTokenRequest") {
        LicenseTokenResponse {
            hresult: store::INVALID_ARGUMENT,
            token: String::new(),
        }
    } else {
        match quick_xml::de::from_reader::<_, LicenseTokenRequest>(bytes) {
            Ok(request) => session.query_license(request).await,
            Err(_) => LicenseTokenResponse {
                hresult: store::INVALID_ARGUMENT,
                token: String::new(),
            },
        }
    };
    quick_xml::se::to_string(&response)
        .ok()
        .filter(|s| s.len() <= u16::MAX as usize)
        .unwrap_or_else(|| {
            "<LicenseTokenResponse><HResult>2147500037</HResult><Token/></LicenseTokenResponse>"
                .into()
        })
        .into_bytes()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn accepts_only_expected_root_without_dtd() {
        assert!(root_is(b"<StoreContextRequest/>", b"StoreContextRequest"));
        assert!(root_is(
            b"<?xml version=\"1.0\"?>\n<StoreContextRequest/>",
            b"StoreContextRequest"
        ));
        assert!(!root_is(
            b"<!DOCTYPE x><StoreContextRequest/>",
            b"StoreContextRequest"
        ));
        assert!(!root_is(b"<Other/>", b"StoreContextRequest"));
        assert!(!root_is(
            b"<StoreContextRequest injected=\"1\"/>",
            b"StoreContextRequest"
        ));
    }
}
